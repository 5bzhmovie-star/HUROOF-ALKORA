import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import {resolve} from 'node:path';
export default defineConfig({plugins:[react()],resolve:{alias:{'@':resolve(import.meta.dirname)}},build:{outDir:'dist/client',emptyOutDir:true,sourcemap:false,chunkSizeWarningLimit:600},publicDir:'public'});
